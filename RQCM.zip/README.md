
# Recursive Quantum Consciousness Model (RQCM)

This Overleaf-compatible LaTeX project presents the RQCM theory, integrating recursive observer dynamics, entropy modeling, and quantum-relativistic perspectives. To use:

1. Upload all files to Overleaf.
2. Edit `main.tex` as needed.
3. Compile with PDFLaTeX.
